# Changelog

All notable changes to this package are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and
this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Entries before 1.0.0 were reconstructed from git history after the fact, so they
summarise each release rather than record it completely.

## [1.4.0] - 2026-09-25

### Added

- `canvas.downloadFile(client, courseId, fileId, { via: 'public-url' })` downloads a course file
  through a signed link from `GET /api/v1/files/:id/public_url` instead of the file's own URL. That
  URL is `/files/:id/download`, which is not an `/api/v1` path, so no Developer Key scope can cover
  it: with **Enforce Scopes** on, Canvas can refuse the token there while every API read works, and
  file import fails at the download step. A development Canvas already does, because it turns on two
  account flags that are off by default elsewhere (`enable_file_access_with_api_tokens`,
  `disable_adding_uuid_verifier_in_api`); hosted Canvas can start doing so whenever Instructure
  turns them on. Such keys need `url:GET|/api/v1/files/:id/public_url` added for this option.

  Opt-in. Without `via`, or with `via: 'file-url'`, `downloadFile` sends exactly the requests it did
  in 1.3.0. Either way the course-scoped metadata lookup runs first, so a link is only requested for
  a file Canvas has just confirmed belongs to the course, and the size check against that metadata,
  `maxBytes`, the HTML refusal, and the redirect limit all still apply.

  If Canvas refuses the `public_url` request with 401, 403, or 404 (a key without that scope, for
  instance), the download falls back to the file URL. If storage refuses the signed link with 401 or
  403, as it would an expired one, one new link is requested. An unknown `via` is rejected with 400
  before any request is sent.
- `ApiClient.download(url, { credentials: 'none' })` downloads a signed link that carries its own
  authorization. The new option types are exported as `canvas.DownloadFileOptions` and
  `canvas.CanvasDownloadOptions`.

### Security

- A signed link never receives the bearer token or cookie jar, on any request or redirect, including
  one on the Canvas origin. With no credential at stake it may start on an approved storage host
  (`*.inscloudgate.net`, `*.canvas-user-content.com`, signed Amazon S3, or
  `allowedDownloadHostSuffixes`) as well as on Canvas, under the same HTTPS, standard-port, and
  no-embedded-credentials rules as a redirect. Any other host is refused before a request is sent. A
  Canvas file URL must still start on Canvas.
- A 401 from a signed link is thrown rather than answered with a token refresh. The token was never
  sent, so refreshing it would cost a round trip and fix nothing. Error messages name the rejected
  origin, never the signed link.

## [1.3.0] - 2026-09-11

### Fixed

- `canvas.buildAuthorizeUrl` now sends the requested scopes as a single space-delimited `scope`
  param instead of one repeated `scope` param per scope. OAuth 2.0 (RFC 6749 §3.3) defines `scope`
  as one parameter carrying a space-delimited list, and Canvas reads `params[:scope]` and splits it
  on whitespace — but Rack collapses a repeated key to its *last* value, so every scope except the
  final one was silently dropped.

  The failure was invisible until it mattered: with **Enforce Scopes** off, the Developer Key
  ignores scopes entirely and nothing misbehaves. With it on, the one surviving scope is still a
  valid subset, so authorization *succeeds* and Canvas mints a token carrying only that scope —
  every other endpoint then fails with 401 at request time, far from the cause. Callers passing two
  or more scopes should re-authorize to obtain a correctly scoped token; existing tokens keep the
  single scope they were granted.

  Passing `scopes: []` now omits the parameter altogether rather than sending an empty `scope=`,
  which Canvas parses as zero scopes and rejects outright with `invalid_scope` on an Enforce Scopes
  key.

## [1.2.0] - 2026-08-20

### Added

- `canvas.resolveSubmissionFeedbackWrites(report, gradeItemId, inputs, { maxBytesPerFile })`,
  `canvas.preflightSubmissionFeedbackExport(client, options)`, and
  `canvas.postSubmissionFeedbackPdfs(client, options)` attach one application-generated feedback PDF
  to each student's Canvas submission as an instructor comment. Same three-step shape as the grade
  export — pure resolution, no-write preflight, then the side-effecting call — because an instructor
  should see which students are about to receive a file, and which are about to be skipped, before
  anything reaches Canvas.
- The preflight returns `fileCount`, `totalBytes`, `assignmentName`, `postManually`, and a
  `batchFingerprint` covering the target and every feedback id, student, attempt, filename, comment
  text, and PDF hash. The export re-reads the assignment and recomputes the fingerprint immediately
  before the first upload, so a file swapped after approval, or a posting policy changed during
  review, is refused as `preflight-stale` rather than uploaded.
- Feedback is attached to the submission attempt it was written about, verified against Canvas's
  `submission_history` before any byte is uploaded. Canvas will happily accept feedback on a first
  draft against a resubmission, and neither the instructor nor the student can see that it happened.
- Per-student outcomes rather than an exception once the first upload starts: one result per
  `batch.writes` entry, in that order, each `attached`, `failed`, `unknown`, or `not-attempted` with
  the stage that stopped it. One bad PDF does not erase the record of the students who succeeded, an
  `attach-comment` failure carries the Canvas `fileId` so the orphaned upload can be found, and an
  interrupted comment write is reported as `unknown` rather than `failed` — Canvas exposes no
  idempotency key for that write, so re-running it blind can leave a student with two copies.
- Losing authorization stops the export and marks the remaining items `not-attempted`. It is a fact
  about the run, not about one student, and 280 identical errors bury the one that mattered.
- `ApiClient.uploadFile(path, file)` implements Canvas's three-request upload protocol: Canvas
  negotiates the destination, the bytes go there as `multipart/form-data` with every signed
  `upload_params` field copied verbatim and the file last, and the result is confirmed back on the
  Canvas origin. The destination is never a caller argument, so this is not a general-purpose
  uploader.
- `allowedUploadHostSuffixes` on the Canvas config and `ApiClientOptions`. Canvas frequently names
  an Instructure gateway, a `*.canvas-user-content.com` host, or a signed Amazon S3 URL as the
  upload destination; those are permitted already, and anything else has to be added deliberately.
  Kept separate from `allowedDownloadHostSuffixes` because letting a host serve a file back is a
  smaller decision than letting student feedback be sent to it.
- `canvas.CanvasSubmissionFeedbackError` (`roster-coverage`, `course-mismatch`,
  `assignment-mismatch`, `empty-batch`, `partial-export`, `invalid-feedback`, `preflight-stale`,
  `unsupported-grading`, `unsupported-group-assignment`) and `canvas.CanvasUploadError`, which
  extends `CanvasApiError` with the upload `stage`. Group assignments are refused on purpose:
  whether one PDF belongs to one student or to a whole group is a product decision, and Canvas would
  silently pick one.

### Security

- The Canvas bearer token and cookie jar are never sent to an upload destination, which Canvas
  itself requires. Credentials return only for a confirmation URL on the exact configured Canvas
  origin, and a confirmation that bounces through another storage host does not regain them.
- Upload destinations are matched on label boundaries, so `canvas-user-content.com.attacker.test` is
  not a match, and HTTP, nonstandard ports, and URLs carrying embedded credentials are rejected
  before any byte is sent. A rejected destination reports `initialize-upload`, which is the caller's
  evidence that nothing left the server.
- Every PDF is validated at resolution and again before the write: `.pdf` filename with no path
  separators or control characters, non-empty bytes within `maxBytesPerFile`, and a real `%PDF-`
  signature in the first 1 KB. The filename and content type are supplied by the caller, so neither
  is evidence of what the file actually is.
- Refusal messages name the stage and the safe ids needed to diagnose them, and never a token,
  signed upload parameter, signed URL, PUID, PDF content, or feedback text.

## [1.1.0] - 2026-08-17

### Added

- `canvas.matchCourseRoster(client, courseId, appUserKeys, options?)` and the underlying pure
  `matchRosterByIntegrationId(courseId, roster, appUserKeys)` pair a course roster with an
  application's own users on `integration_id` — at UBC, the PUID. No fallback key, deliberately:
  an unmatched student is a line in a report someone reads, while a mis-matched one is a grade
  filed against the wrong person. The resulting `LmsRosterMatchReport` separates `matched`,
  `appOnly`, `rosterOnly`, and `ambiguous`, and those sets are disjoint so a UI cannot double-count
  anyone.
- `LmsRosterMatchReport` carries the course whose roster produced it. A Canvas user id is the same
  in every course a student takes, so without that stamp a score computed for one section would
  post cleanly against another and nothing downstream would catch it.
- `canvas.explainUnmatched(client, courseId, report, options?)` resolves unmatched application users
  against the course's concluded enrollments, turning `unknown` into `enrollment-ended` (with the
  former enrollment attached) or `not-enrolled`. The active roster cannot tell those apart — a
  student who dropped is simply absent — and the difference is what separates "3 students dropped
  after week 8" from a linked-course mistake. Reads `completed`, `inactive`, and `rejected`;
  `deleted` is not an accepted `enrollment_state` filter on Canvas's course-users endpoint, and a
  deleted enrollment reads as never-enrolled anyway.
- `canvas.getSubmissions(client, options)` reads student work, listing attachments without fetching
  their bytes so a course-wide read does not pull every file in the class. Paginates fully; excludes
  Canvas's unsubmitted placeholders unless asked for them.
- `canvas.resolveSubmissions(report, gradeItemId, submissions)` re-keys submissions from Canvas user
  ids to the application's own identifiers and reports the ones it could not place. It validates
  both course and assignment on every row and retains the requested assignment on an empty result.
  Without it every caller hand-rolls the same join, and a student the join drops is indistinguishable
  from one who did not submit.
- `canvas.downloadSubmissionAttachment(client, options)` names the course, assignment, student, and
  attachment rather than accepting a URL, and re-resolves it through Canvas before fetching — the
  same course-scoped lookup `downloadFile` does, for the same reason. `maxBytes` is required, since
  the bytes are student-uploaded and buffered whole in memory. The limit is validated at runtime,
  not only by TypeScript.
- `canvas.resolveGradeWrites(report, gradeItemId, grades)`, `canvas.postGrades(client, options)`, and
  `canvas.waitForProgress(client, progressId, options?)` write grades and student-visible comments
  back to a Canvas assignment. Resolving is separate from sending so an instructor can review who
  will be skipped first; sending is one bulk `update_grades` request rather than one per student.
- `canvas.preflightGradeExport(client, options)` runs every check and reads the posting policy
  without writing. The policy is only actionable before the write — under an automatic policy a
  generated comment is visible the instant it lands — so returning it from `postGrades` alone was
  too late to warn anyone. `postGrades` always repeats the assignment read immediately before writing
  and refuses `preflight-stale` if the reviewed policy, grading type, points possible, or assignment
  name changed.
- Grade batches carry the assignment they were computed for, not just the course. A batch for Lab 1
  posts cleanly to Lab 2 otherwise: same course, same students, same ids, and Canvas checks only
  that Lab 2 belongs to the course.
- `canvas.CanvasGradeExportError` refuses eight states before anything reaches Canvas, each of which
  would otherwise produce a write that succeeds while being wrong: a roster with no `integration_id`
  on anyone (a missing SIS-read permission, not an empty class), a batch matched against a different
  course, a batch computed for a different assignment, an empty batch (Canvas accepts it and reports
  success), a partial export the caller did not ask for, an empty or non-finite grade operation, a
  stale instructor preflight, and an anonymously or moderately graded assignment.
- `matchRosterByIntegrationId` and `matchCourseRoster` accept `{ appUserId, key }` records as well as
  bare key strings. With bare strings an identical key repeated is one person; with account ids, two
  accounts holding one key is a duplicate in the application and resolves to no grade at all —
  matching how duplicate Canvas `integration_id` values were already treated.

### Changed

- Canvas course roster reads no longer request undocumented `include[]=email`. Grade and submission
  identity matching uses `integration_id` exclusively, so collecting email was unnecessary.

## [1.0.4] - 2026-08-11

## [1.1.0] - 2026-08-17

### Added

- `canvas.getCourseUsers(client, courseId, options?)` and
  `moodle.getCourseUsers(client, courseId, options?)` read a course roster as normalized
  `LmsRosterUser` entries. Canvas defaults to active and invited student enrollments and always
  requests `include[]=email`; Moodle filters to the `student` role client-side, since its web
  service returns every enrolled user. Both paginate fully — a roster truncated at the first page
  is worse than a failed read, because the people cut off resurface later as unmatched and look
  like a data problem.
- `LmsRosterUser` normalizes the four identity fields worth matching on — `integrationId`,
  `sisId`, `loginId`, `email` — across both providers. Canvas `integration_id` holds the PUID at
  UBC, the identifier CWL authenticates against, making it the strongest key for matching a roster
  against CWL-authenticated accounts. Moodle has no equivalent and leaves it undefined.
- `rosterFieldCoverage(users)` reports how many roster entries carried each identity field. Canvas
  serializes `integration_id`, `sis_user_id`, and `login_id` only for callers permitted to read SIS
  data, so a complete roster can come back with all three empty and produce a total match failure
  indistinguishable from nobody having signed up. Check coverage before acting on who failed to
  match — particularly before offering to remove them.

### Changed

- The roster-matching guidance in `agents_canvas.md` now ranks Canvas `integration_id` above email
  and student number, warns against comparing a PUID to a student-number field, and documents the
  SIS-permission gate. Its hand-rolled roster snippet is replaced by `getCourseUsers`.

## [1.0.3] - 2026-08-06

### Fixed

- Canvas file downloads now follow HTTPS redirects to Instructure's official
  `*.canvas-user-content.com` content hosts.

### Security

- Canvas bearer tokens and cookies remain restricted to the configured Canvas
  origin when a download redirects to a Canvas content host.

## [1.0.2] - 2026-08-06

### Changed

- Canvas download URL rejections now identify the rejected protocol or origin
  without exposing paths, signed query parameters, or embedded credentials.

## [1.0.1] - 2026-08-06

### Fixed

- Canvas file downloads now follow the HTTPS redirect chain used by hosted
  Instructure file storage, including `*.inscloudgate.net` and signed Amazon S3
  object hosts. The initial file URL must still belong to the configured Canvas
  origin.

### Security

- Canvas bearer tokens, cookies, and host headers are never forwarded to an
  off-origin download host. Once a download leaves the Canvas origin, those
  credentials remain stripped for the rest of the redirect chain, even if a
  later redirect points back to Canvas.
- Unknown hosts, HTTP downgrades, URLs containing credentials, nonstandard
  external HTTPS ports, and excessive redirect chains remain blocked.
- Self-hosted Canvas deployments can opt into reviewed file-service domains with
  `allowedDownloadHostSuffixes`; matching applies to the named host and its
  subdomains and never permits credentials to be forwarded.

## [1.0.0] - 2026-08-05

First stable release. Contains breaking changes to the normalized resource types
and to `LmsError` — migration notes are inline below.

### Removed

- **Breaking.** `provider` is gone from `LmsCourse`, `LmsCourseSection`,
  `LmsFile`, `LmsGradeItem`, and `LmsGrade`. Every resource is reached through a
  provider-specific namespace (`canvas.*` / `moodle.*`), so the caller already
  knows which LMS a result came from, and no call can return a mixed list.

  *Migration:* record the provider yourself when persisting these objects.
  TypeScript callers get a compile error. **JavaScript callers get nothing** —
  `course.provider` silently becomes `undefined` — so grep for `.provider` on
  these objects before upgrading. This also changes any HTTP response that
  passes them through unmodified.

### Changed

- **Breaking.** `LmsError.provider` is typed `string` rather than
  `'canvas' | 'moodle'`. `core/` is the abstraction the provider
  implementations depend on, so it no longer enumerates them; adding a provider
  requires no change there.

  *Migration:* assigning `err.provider` to a `'canvas' | 'moodle'` variable no
  longer compiles, and a `switch` over it is no longer exhaustiveness-checked.
  Assigning *into* the field is unchanged.

- **Breaking.** The Canvas auth router accepts only same-site paths in
  `/login?returnTo=`; anything else falls back to `/`. A caller passing an
  absolute URL — even a same-origin one — now lands on `/`. See Security.

### Security

- Fixed an open redirect in the Canvas OAuth callback. `/login` is a public GET,
  so `?returnTo=` was attacker-controllable, and the value was passed verbatim
  to `res.redirect` after a successful token exchange. Absolute
  (`https://evil.example`), scheme-relative (`//evil.example`), and backslash
  (`/\evil.example`) forms all worked. For a user who had already authorized the
  Developer Key, Canvas re-approves without a consent screen, so the hop off-site
  was invisible.

### Fixed

- `POST /logout` on the Canvas auth router now deletes stored tokens even when
  Canvas rejects the revoke. The revoke was previously awaited before the delete,
  and it throws on any non-2xx — which is what Canvas returns for an already
  expired or already revoked token. The delete was skipped and the request 500'd,
  so disconnecting was impossible for exactly the users whose tokens most needed
  clearing. Revoking is now best-effort; a failed *delete* still surfaces as an
  error.

### Documentation

- Corrected the documented default for `maxPages`, which claimed 100 in its
  JSDoc, the README, and `agents_canvas.md` while the code has always used 500.
  100 is the `per_page` value — rows per request, not request count — so
  `maxPages: 200` lowered the ceiling for anyone trying to raise it. Now pinned
  by a test.
